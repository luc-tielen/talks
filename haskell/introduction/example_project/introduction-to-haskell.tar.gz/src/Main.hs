module Main where

main :: IO ()
main = do
  putStrLn "hello world"
