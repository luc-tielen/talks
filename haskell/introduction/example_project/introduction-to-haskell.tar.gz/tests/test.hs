{-# OPTIONS_GHC -F -pgmF tasty-discover #-}
